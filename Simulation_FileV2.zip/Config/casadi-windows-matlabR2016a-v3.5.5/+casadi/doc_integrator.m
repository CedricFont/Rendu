function varargout = doc_integrator(varargin)
    %DOC_INTEGRATOR Get the documentation string for a plugin.
    %
    %  char = DOC_INTEGRATOR(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(783, varargin{:});
end
