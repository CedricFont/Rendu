function varargout = doc_linsol(varargin)
    %DOC_LINSOL Get the documentation string for a plugin.
    %
    %  char = DOC_LINSOL(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(840, varargin{:});
end
