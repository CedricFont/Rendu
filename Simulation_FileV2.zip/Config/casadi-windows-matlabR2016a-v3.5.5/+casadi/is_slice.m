function varargout = is_slice(varargin)
    %IS_SLICE Check if an index vector can be represented more efficiently as a slice.
    %
    %  bool = IS_SLICE([int] v, bool ind1)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(203, varargin{:});
end
