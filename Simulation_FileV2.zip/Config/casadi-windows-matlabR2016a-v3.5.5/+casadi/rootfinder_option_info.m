function varargout = rootfinder_option_info(varargin)
    %ROOTFINDER_OPTION_INFO Get documentation for a particular option.
    %
    %  char = ROOTFINDER_OPTION_INFO(char name, char op)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(820, varargin{:});
end
