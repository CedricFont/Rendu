function varargout = convexify(varargin)
    %CONVEXIFY Find first nonzero If failed, returns the number of rows.
    %
    %  MX = CONVEXIFY(MX H, struct opts)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(874, varargin{:});
end
