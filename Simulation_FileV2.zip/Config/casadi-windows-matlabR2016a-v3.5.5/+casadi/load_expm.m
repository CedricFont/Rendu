function varargout = load_expm(varargin)
    %LOAD_EXPM Explicitly load a plugin dynamically.
    %
    %  LOAD_EXPM(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(853, varargin{:});
end
