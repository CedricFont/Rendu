function varargout = nlpsol_option_info(varargin)
    %NLPSOL_OPTION_INFO Get documentation for a particular option.
    %
    %  char = NLPSOL_OPTION_INFO(char name, char op)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(809, varargin{:});
end
