function varargout = nlpsol_n_out(varargin)
    %NLPSOL_N_OUT Number of NLP solver outputs.
    %
    %  int = NLPSOL_N_OUT()
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(805, varargin{:});
end
