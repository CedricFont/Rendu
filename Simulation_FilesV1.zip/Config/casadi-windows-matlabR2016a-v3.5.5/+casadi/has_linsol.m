function varargout = has_linsol(varargin)
    %HAS_LINSOL Check if a particular plugin is available.
    %
    %  bool = HAS_LINSOL(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(838, varargin{:});
end
