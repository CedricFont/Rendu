function varargout = nlpsol_options(varargin)
    %NLPSOL_OPTIONS Get all options for a plugin.
    %
    %  {char} = NLPSOL_OPTIONS(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(807, varargin{:});
end
