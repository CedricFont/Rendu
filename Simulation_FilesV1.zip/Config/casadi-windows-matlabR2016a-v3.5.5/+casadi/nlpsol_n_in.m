function varargout = nlpsol_n_in(varargin)
    %NLPSOL_N_IN Number of NLP solver inputs.
    %
    %  int = NLPSOL_N_IN()
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(804, varargin{:});
end
