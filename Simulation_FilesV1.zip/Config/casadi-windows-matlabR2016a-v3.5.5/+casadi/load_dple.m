function varargout = load_dple(varargin)
    %LOAD_DPLE Explicitly load a plugin dynamically.
    %
    %  LOAD_DPLE(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(847, varargin{:});
end
