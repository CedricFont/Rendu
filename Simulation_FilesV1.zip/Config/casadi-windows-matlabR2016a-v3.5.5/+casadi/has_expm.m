function varargout = has_expm(varargin)
    %HAS_EXPM Check if a particular plugin is available.
    %
    %  bool = HAS_EXPM(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(852, varargin{:});
end
