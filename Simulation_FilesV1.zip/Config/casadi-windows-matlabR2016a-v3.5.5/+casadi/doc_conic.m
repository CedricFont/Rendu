function varargout = doc_conic(varargin)
    %DOC_CONIC Get the documentation string for a plugin.
    %
    %  char = DOC_CONIC(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(799, varargin{:});
end
