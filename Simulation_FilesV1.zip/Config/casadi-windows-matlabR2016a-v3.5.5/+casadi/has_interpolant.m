function varargout = has_interpolant(varargin)
    %HAS_INTERPOLANT Check if a particular plugin is available.
    %
    %  bool = HAS_INTERPOLANT(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(856, varargin{:});
end
