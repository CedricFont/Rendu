function varargout = normalized_setup(varargin)
    %NORMALIZED_SETUP 
    %
    %  std::ostream & = NORMALIZED_SETUP()
    %  NORMALIZED_SETUP(std::istream & stream)
    %
    %
  [varargout{1:nargout}] = casadiMEX(38, varargin{:});
end
