function varargout = dple_n_out(varargin)
    %DPLE_N_OUT Get the number of QP solver outputs.
    %
    %  int = DPLE_N_OUT()
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(845, varargin{:});
end
