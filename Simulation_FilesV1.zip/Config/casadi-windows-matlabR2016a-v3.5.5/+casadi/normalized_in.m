function varargout = normalized_in(varargin)
    %NORMALIZED_IN 
    %
    %  int = NORMALIZED_IN(std::istream & stream, double & ret)
    %
    %
  [varargout{1:nargout}] = casadiMEX(40, varargin{:});
end
