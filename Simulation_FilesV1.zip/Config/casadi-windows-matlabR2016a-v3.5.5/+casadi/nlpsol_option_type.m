function varargout = nlpsol_option_type(varargin)
    %NLPSOL_OPTION_TYPE Get type info for a particular option.
    %
    %  char = NLPSOL_OPTION_TYPE(char name, char op)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(808, varargin{:});
end
