function varargout = rootfinder_n_out(varargin)
    %ROOTFINDER_N_OUT Number of rootfinder outputs.
    %
    %  int = ROOTFINDER_N_OUT()
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(817, varargin{:});
end
