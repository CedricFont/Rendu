function varargout = conic_n_in(varargin)
    %CONIC_N_IN Get the number of QP solver inputs.
    %
    %  int = CONIC_N_IN()
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(792, varargin{:});
end
