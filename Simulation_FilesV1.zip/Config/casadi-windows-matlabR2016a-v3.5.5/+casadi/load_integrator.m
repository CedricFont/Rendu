function varargout = load_integrator(varargin)
    %LOAD_INTEGRATOR Explicitly load a plugin dynamically.
    %
    %  LOAD_INTEGRATOR(char name)
    %
    %
    %
    %
  [varargout{1:nargout}] = casadiMEX(782, varargin{:});
end
